import React from "react";
import CK from "./CK.jsx";
import "./style.css";

export default function App() {
  return <CK />;
}
